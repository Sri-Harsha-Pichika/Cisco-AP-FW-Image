/*
 * Copyright (c) 2003-2014 by cisco Systems, Inc.
 * All rights reserved.
 */

var product = <!--#exec cmd="show dot11 html-support model"-->

/*
 * Platform check for panda 2600
 */
function iswap2600() {
   if (product.match("WAP-CAP260") || product.match("WAP-SAP260")) return true;
   else return false;
}
/*
 * Platform check for panda 1600
 */
function iswap1600() {
   if (product.match("WAP-CAP160") || product.match("WAP-SAP160")) return true;
   else return false;
}
/*
 * Platform check for panda 702
 */
function iswap700() {
   if (product.match("WAP-CAP70") || product.match("WAP-SAP70")) return true;
   else return false;
}
/*
 * Is this panda AP?
 */
function isPanda() {
   if (iswap2600() || iswap1600() || iswap700())  return true;
   else return false;
}
