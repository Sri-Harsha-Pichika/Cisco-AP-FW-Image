/*
 * Copyright (c) 2003-2015 by cisco Systems, Inc.
 * All rights reserved.
 */

var tmp;
var title = ""
var time = ""
var hostname = ""
var product = <!--#exec cmd="show dot11 html-support model"-->
var platform_capabilities = '<!--#exec cmd="show dot11 html-support platform-cap"-->';
var radio_station_role = '<!--#exec cmd="show dot11 html-support radio-role"-->';
var radio_interfaces = '<!--#exec cmd="show dot11 html-support interfaces"-->';
var inline_power = '<!--#exec cmd="show dot11 html-support inline-power"-->';
var inline_power_split = inline_power.split(":");
var sntp = '<!--#exec cmd="show sntp"-->';
var inventory = function(){/*<!--#exec cmd="show inventory"-->*/}.toString().slice(14,-3);
var clockTime = '<!--#exec cmd="show clock"-->';
var sysUptime = "<!--#exec cmd='show dot11 html-support uptime'-->";
var ethernet_type = '<!--#exec cmd="show dot11 html-support ether-type"-->';
var httpLifeTimeout = '<!--#exec cmd="show dot11 html-support http-life-timeout"-->';
var httpIdleTimeout = '<!--#exec cmd="show dot11 html-support http-idle-timeout"-->';
var ethernet_interface = '<!--#exec cmd="show dot11 html-support ether-name"-->';
var logoutError = "ERROR:\nError occured while clearing Browser credentials.";

hostname = find_string(/uptime/,DLIM_WhSp,0, sysUptime);
if (token_string(DLIM_WhSp, 10, sntp) == "Synced") {
	time = clockTime.match(/\d{2}:\d{2}:\d{2}/);
    time += " " + clockTime.match(/ \w{3} \w{3} \d{1,2} \d{4}/);
} else {
	time = grep_string(/uptime/,sysUptime);
}

if (product.match("AIR-BR") || product.match("ORVAL")) {
    title = "Cisco IOS Series Bridge"
} else {
    title = "Cisco IOS Series AP"
}

function isGigabit() {
   if (ethernet_type.match("GigabitEthernet")) return true;
   else return false;
}

function isFastEthernet() {
   if (ethernet_type.match("FastEthernet")) return true;
   else return false;
}

function hasCapability(capability) {
   if (platform_capabilities.match(":"+capability+":TRUE")) return true;
   else return false;
}

function isPegasus() {
   if (product.match("AIR-BR14")) return true;
   else return false;
}

function is520() {
	if (product.match("AIR-AP521")) return true;
    else return false;
}

function is1300() {
   if (product.match("AIR-BR13") || product.match("ORVAL") ) return true;
   else return false;
}

function isBridge() {
   if (isPegasus() || is1300()) return true;
   else return false;
}

function is350() {
   if (product.match("AIR-AP350")) return true;
   else return false;
}

function is1100() {
   if (product.match("AIR-AP110")) return true;
   else return false;
}

function is1130() {
   if (product.match("AIR-AP113")) return true;
   else return false;
}

function is1200() {
   if (product.match("AIR-AP12")) return true;
   else return false;
}

function is1250() {
   if (product.match("AP125")) return true;
   else return false;
}

function is1410() {
   if (product.match("AIR-BR141")) return true;
   else return false;
}

function is1430() {
   if (product.match("AIR-BR143")) return true;
   else return false;
}
function is3500() {
   if (product.match("AIR-CAP350") || product.match("AIR-SAP350")) return true;
   else return false;
}
function is3600() {
   if (product.match("AIR-CAP360") || product.match("AIR-SAP360")) return true;
   else return false;
}
function is2600() {
   if (product.match("AIR-CAP260") || product.match("AIR-SAP260")) return true;
   else return false;
}
function is2700() {
   if (product.match("AIR-CAP270") || product.match("AIR-SAP270")) return true;
   else return false;
}
function is3700() {
   if (product.match("AIR-CAP370") || product.match("AIR-SAP370")) return true;
   else return false;
}
function is1600() {
   if (product.match("AIR-CAP160") || product.match("AIR-SAP160")) return true;
   else return false;
}
function is1550() {
   if (product.match("AIR-CAP155") || product.match("AIR-SAP155")) return true;
   else return false;
}

function is1570() {
   if (product.match("AIR-AP157")) return true;
   else return false;
}

function is1570_cableModem() {
   if (product.match("AIR-AP1572IC") || product.match("AIR-AP1572EC")) return true;
   else return false;
}

function isUniversal() {
   if (product.match("AIR-AP702E-UXK9") || product.match("AIR-AP702I-UXK9") ||
       product.match("WAP-AP702I-UXK9") || product.match("AIR-AP702W-UXK9") ||
       product.match("AIR-AP1602E-UXK9") || product.match("AIR-AP1602I-UXK9") ||
       product.match("WAP-AP1602E-UXK9") || product.match("WAP-AP1602I-UXK9") ||
       product.match("AIR-AP2602E-UXK9") || product.match("AIR-AP2602I-UXK9") ||
       product.match("WAP-AP2602E-UXK9") || product.match("WAP-AP2602I-UXK9") ||
       product.match("AIR-AP2702E-UXK9") || product.match("AIR-AP2702I-UXK9") ||
       product.match("AIR-AP3602E-UXK9") || product.match("AIR-AP3602I-UXK9") ||
       product.match("AIR-AP3602P-UXK9") || product.match("AIR-AP3702P-UXK9") ||
       product.match("AIR-AP3702E-UXK9") || product.match("AIR-AP3702I-UXK9") ||
       product.match("AIR-AP1532E-UXK9") || product.match("AIR-AP1532I-UXK9") ||
       product.match("AIR-AP1572E-UXK9") || product.match("AIR-AP1572I-UXK9") ||
       product.match("IW3702-2E-UXK9") || product.match("IW3702-4E-UXK9") ||
       product.match("IW3702H-2E-UXK9") || product.match("IW3702H-4E-UXK9"))
        return true;
   else return false;
}

function is1700() {
   if (product.match("AIR-CAP170") || product.match("AIR-SAP170")) return true;
   else return false;
}

function ethernet_check(ethernet) {
    if(ethernet_interface.match(ethernet)) return true;
    else return false;
}

function isap80() {
   if (product.match("AP80")) return true;
   else return false;
}

function isap803() {
	if (inventory.match("AP803")) return true;
	else return false;
}

function is1530() {
   if (product.match("AIR-SAP153")) return true;
   else return false;
}
function iswap2600() {
   if (product.match("WAP-CAP260") || product.match("WAP-SAP260")) return true;
   else return false;
}
function iswap1600() {
   if (product.match("WAP-CAP160") || product.match("WAP-SAP160")) return true;
   else return false;
}
function isIW3702() {
   if (product.match("IW3702")) return true;
   else return false;
}

function isMultipleSSIDFeatureSupported() {
	return isIW3702() || isap803() || isap5100();
}

/*
is702w() function is used only for sardina ap
To check this is a sardina ap or nor
*/
function is702w() {
   if (product.match("AP702W")) return true;
   else return false;
}
function iswap700() {
   if (product.match("WAP-CAP70") || product.match("WAP-SAP70")) return true;
   else return false;
}
function isPanda() {
   if (iswap2600() || iswap1600() || iswap700())  return true;
}
function isap5100() {
   if (product.match("1783-WAP")) return true;
   else return false;
}
function is1532E() {
   if (product.match("AIR-SAP1532E")) return true;
   else return false;
}

timeOutValue =  (tmp = httpIdleTimeout.match(/Server idle time-out: (\S+) seconds/)) ? tmp[1] : 600;
setTimeout('clearCredentials()', parseInt(timeOutValue) * 1000);

function logoutNow()
{
  if (window.confirm("Are you sure you want to Logout?")) {
    clearCredentials();
    location.reload(true);
  }
}

function clearCredentials()
{
  if (navigator.userAgent.match(/(Firefox|Navigator)/)) {
    var xmlhttp = createXMLObject();
    if (xmlhttp) {
      xmlhttp.open("GET", "/?sling:authRequestLogin=1", false, "anonymous", "null");
      xmlhttp.send("");
      xmlhttp.abort();
    } else {
      alert(logoutError);
    }
  } else {
    if(!document.execCommand("ClearAuthenticationCache")) {
      alert(logoutError);
    }
  }
}

function createXMLObject()
{
  try {
    if (window.XMLHttpRequest) {
      xmlHttp = new XMLHttpRequest();}
    } catch (e) {
      xmlHttp = false
    }
  return xmlHttp;
}

function childMenu(exist, current, target, nameMenu, nameCLI)
{
  document.write('<tr><td colspan="4" bgcolor="003333"><img src="images/pixel.gif" alt="" border="0" width="1" height="1"></td></tr>');
  document.write('<tr><td bgcolor="#cccccc" background="images/apps_leftnav_yellow.gif">&nbsp;</td>');
  document.write('<td bgcolor="#cccccc">&nbsp;</td>');
  document.write('<td bgcolor="#cccccc">');
  if (exist) {
    if (current) {
      document.write('<a href='+target+' class="apphinavchild">');
      document.write(nameMenu);
    } else {
      document.write('<a href='+target+' class="apphinavchildlink">');
      document.write(nameMenu);
    }
    document.write('</a>');
  } else {
    document.write('<font color="#666666" face="Arial, Helvetica, sans-serif" size="2">');
    document.write(nameMenu);
    document.write('</font>');
  }
  document.write('</td><td bgcolor="#cccccc">&nbsp;</td></tr>');
}

function mainMenu(target,nameMenu, plus){

  document.write('<tr>')
  document.write('<td bgcolor="#669999" background="images/apps_leftnav_green.gif"><img src="images/pixel.gif" alt="" width="8" height="17" border="0"></td>')
  document.write('<!-- note the double href tag to make the whole table cell a link in IE -->')
  document.write('<td colspan="2" bgcolor="#669999"><a href="#"></a><a href="' + target + '" class="apphinavpeer">' + nameMenu +'</a></td>')
  if(plus){
    document.write('<td bgcolor="#669999" width="33" >')
    document.write('<div align="center"><img src="images/pixel.gif" alt="" border="0" width="1" height="1"><img src="images/hinav_plus.gif" width="13" height="7"></div>')
    document.write('</td>')
  }else{
    document.write('<td bgcolor="#669999" >')
    document.write('<div align="center"><img src="images/pixel.gif" alt="" border="0" width="1" height="1"></div>')
    document.write('</td>')
  }
  document.write('</tr>')
  document.write('<tr>')
  document.write(' <td colspan="4" bgcolor="003333"><img src="images/pixel.gif" alt="" border="0" width="1" height="1"></td>')
  document.write('</tr>')

}
var titleOfCurrentPage = "not-set";

/*
 * Some pages (ap_services) repeat the menu information, so we save it here.
 */
var serviceArr = new Array();
function serviceObj(link, desc, func) {
   this.link = link;
   this.desc = desc;
   this.func = func;
}

/*
 * Display the top part of the main menu
 */
function menuOpen()
{
  var str = '';
  str += '<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff" background="">';
  str += '  <tr>';
  str += '    <td width="8" bgcolor="#336666" background="images/apps_leftnav_dkgreen.gif">';
  str += '      <img src="images/pixel.gif" alt="" width="8" height="18" border="0"></td>';
  str += '    <td width="8" bgcolor="#336666">';
  str += '      <img src="images/pixel.gif" alt="" height="1" width="8" border="0"></td>';
  str += '    <td width="100%" bgcolor="#336666">';
  str += '      <img src="images/pixel.gif" alt="" height="1" width="128" border="0"></td>';
  str += '    <td width="18" bgcolor="#336666" valign="top" align="right">';
  str += '      <img src="images/apps_leftnav_upright.gif" alt="" border="0" width="18" height="18"></td>';
  str += '  </tr><tr>';
  str += '    <td colspan="4" bgcolor="003333">';
  str += '      <img src="images/pixel.gif" alt="" border="0" width="1" height="1"></td>';
  str += '  </tr>';
  document.write(str);
}

/*
 * Display a level 1 menu box
 */
function menu_Parent(curPgL2, curPgL1, curPage, curBxL1, curBx, curBxStr)
{
  var str = '';
  var curBoxHasChildren = curBxL1 == "" ? false:true;
  var curBoxIsCurrentPage = curPage.match(curBx) ? true : false;
  var curBoxIsAncestorOfCurrentPage = curBoxHasChildren ? curPgL1 ? curPgL1.match(curBxL1) : false : false;

  var curBoxInSubMenu = curBoxIsCurrentPage || curBoxIsAncestorOfCurrentPage;
  var menuBgcolor = curBoxInSubMenu ? "#ffffff":"#669999";
  var menuClass   = curBoxInSubMenu ? "apphinavchild":"apphinavpeer";
  var menuImage   = curBoxInSubMenu ? "apps_leftnav_yellow.gif":"apps_leftnav_green.gif";
  var menuPlus    = !curBoxInSubMenu && curBoxHasChildren && (curPgL2 != curPgL1) ? "hinav_plus.gif":"pixel.gif";

  if (curBoxIsCurrentPage) {
    titleOfCurrentPage = curBxStr;
  }
  str += '  <tr>';
  str += '    <td bgcolor="' + menuBgcolor + '" background="images/' + menuImage + '">';
  str += '      <img src="images/pixel.gif" alt="" width="8" height="17" border="0"></td>';
  str += '    <!-- note the double href tag to make the whole table cell a link in IE -->';
  str += '    <td colspan="2" bgcolor="' + menuBgcolor + '">';
  str += '      <a href="#"></a><a href="' + curBx + '" class="' + menuClass + '">' + curBxStr +'</a></td>';
  str += '  <td bgcolor="' + menuBgcolor + '">';
  str += '    <div align="center"><img src="images/' + menuPlus + '" width="13" height="7"></div>';
  str += '  </td>';
  str += '  </tr>';
  str += '  <tr>';
  str += '    <td colspan="4" bgcolor="003333">';
  str += '      <img src="images/pixel.gif" alt="" border="0" width="1" height="1"></td>';
  str += '  </tr>';
  document.write(str);
  return(curBoxInSubMenu);
}

/*
 * Display a level 2 menu box
 */
function menu__Child(curPgL2, curPgL1, curPage, curBxL1, curBx, curBxStr, statusFunc, clickFunc)
{
  var str = '';
  var installed = curBxStr.match("-NOT.INSTALLED") ? false : true; //Sometimes a Radio may not be installed
  var curBoxIsCurrentPage = curPage.match(curBx) ? true : false;
  var curBoxIsParentOfCurrentPage = curPgL2 ? curPgL2.match(curBx) : false;
  var i = curBx.indexOf(">"); //Remove overloaded cookie info
  curBx = (i == -1) ? curBx : curBx.slice(0,i);

  var curBoxIsChildOfCurrentPage = curPage.match(curBxL1);
  var curBoxHasSameL1AsCurrentPage = curPgL1 ? curPgL1.match(curBxL1) : false;
  if (!(curBoxIsCurrentPage || curBoxIsChildOfCurrentPage || curBoxIsParentOfCurrentPage || curBoxHasSameL1AsCurrentPage)) {
    return;
  }
  if (statusFunc != "") { /* save data in array for use by services page */
    serviceArr[serviceArr.length] = new serviceObj(curBx, curBxStr, statusFunc);
  }
  if (curBoxIsCurrentPage) {
    titleOfCurrentPage = curBxStr;
  }

  var curBoxInSubMenu = curBoxIsCurrentPage || curBoxIsParentOfCurrentPage;
  var menuBgcolor     = curBoxInSubMenu ? "#ffffff":"#669999";
  var menuClass       = curBoxInSubMenu ? "apphinavchild":"apphinavchildlink";
  var curBoxStrBold   = curBoxInSubMenu ? "<b>" + curBxStr + "</b>": curBxStr;

  // If radio is not installed in slot then not displaying in the sidemenu.
  if (installed) {
    str += '  <tr>';
    str += '    <td bgcolor="#cccccc" background="images/apps_leftnav_yellow.gif">&nbsp;</td>';
    str += '    <td bgcolor="#cccccc">&nbsp;</td>';
    str += '    <td bgcolor="#cccccc">';
    str += '    <a href="' + curBx + '" class="' + menuClass + '"';
    if (clickFunc != "")
      str += '    onclick="' + clickFunc + '"';
    str += '    >' + curBoxStrBold + '</a></td>';
    str += '    <td bgcolor="#cccccc">&nbsp;</td>';
    str += '  </tr>';
    str += '  <tr>';
    str += '    <td colspan="4" bgcolor="003333">';
    str += '      <img src="images/pixel.gif" alt="" border="0" width="1" height="1"></td>';
    str += '  </tr>';
  }
  document.write(str);
}

/*
 * Display the bottom part of the main menu
 */
function menuClose()
{
  var str = '';
  str += '  <tr>';
  str += '    <td colspan="4" bgcolor="003333">';
  str += '      <img src="images/pixel.gif" alt="" border="0" width="1" height="1"></td>';
  str += '  </tr>';
  str += '</table>';
  document.write(str);
}

/*
 * Display the full main menu
 *   may have 1,2 or 3 paramaters depending on the current page
 *   - top level pages have 1 paramater, 2nd level have 2, 3rd level have 3.
 */
function menuDisplay(url)
{
  var curPg = url.match("html") ? url:"ap_home.shtml"; // handle redirect of homepage
  var P1 = arguments.length > 1 ? arguments[1] : null; //Parent1, Ancestor at top layer (may be parent or grandparent)
  var P2 = arguments.length > 2 ? arguments[2] : null; //Parent2, Ancestor at 2nd layer (if not null then is parent)

  menuOpen();
        /*  _______(P2,P1,curPg, curBxL1, curBx, curBxStr);*/
        menu_Parent(P2,P1,curPg, "", "ap_home.shtml", "HOME");
        menu_Parent(P2,P1,curPg, "", "ap_express-setup.shtml", "EXPRESS SET-UP");
      if (hasCapability("DOT11_CORE")) {
        menu_Parent(P2,P1,curPg, "", "ap_express-security.shtml", "EXPRESS SECURITY");
      }

  if (hasCapability("NETWORK_MAP")) {
    if( menu_Parent(P2,P1,curPg, "ap_network-map.shtml", "ap_network-map.shtml", "NETWORK MAP")) {
      if (hasCapability("AP") && !isPegasus()) {
        menu__Child(P2,P1,curPg, "ap_network-map.shtml", "ap_network-map_ap-adjacent-list.shtml", "Adjacent Nodes", "", "");
      }
    }
  }
  if (hasCapability("DOT11_CORE")) {
    if (menu_Parent(P2,P1,curPg, "ap_assoc.shtml", "ap_assoc.shtml", "ASSOCIATION")) {
        menu__Child(P2,P1,curPg, "ap_assoc.shtml", "ap_assoc_adv.shtml", "Activity Timeout", "", "");
    }
  }
  if (  menu_Parent(P2,P1,curPg, "ap_network-if.shtml", "ap_network-if.shtml", "NETWORK INTERFACES")) {
        menu__Child(P2,P1,curPg, "ap_network-if.shtml", "ap_network-if_ipaddress.shtml", "IP Address", "", "");
        if(isGigabit()){
          if (isGigabit() && is1430()) {
            menu__Child(P2,P1,curPg, "ap_network-if.shtml", "ap_network-if_ethernet.shtml>GigabitEthernet0", "GigabitEthernet0", "", "setEthernetLinkCookie('GigabitEthernet0')");
            menu__Child(P2,P1,curPg, "ap_network-if.shtml", "ap_network-if_ethernet.shtml>GigabitEthernet1", "GigabitEthernet1", "", "setEthernetLinkCookie('GigabitEthernet1')");
            menu__Child(P2,P1,curPg, "ap_network-if.shtml", "ap_network-if_ethernet.shtml>GigabitEthernet2", "GigabitEthernet2", "", "setEthernetLinkCookie('GigabitEthernet2')");
            menu__Child(P2,P1,curPg, "ap_network-if.shtml", "ap_network-if_ethernet.shtml>GigabitEthernet3", "GigabitEthernet3", "", "setEthernetLinkCookie('GigabitEthernet3')");
          } else {
            menu__Child(P2,P1,curPg, "ap_network-if.shtml", "ap_network-if_ethernet.shtml", "GigabitEthernet", "", "setEthernetLinkCookie('GigabitEthernet0')");
          }
        }else{
          menu__Child(P2,P1,curPg, "ap_network-if.shtml", "ap_network-if_ethernet.shtml", "FastEthernet", "", "setEthernetLinkCookie('FastEthernet0')");
        }
    pattern = "(Dot11(Radio\\d+)):((\\S+)|(\\S+\\s\\S+)) Radio:\\S*;"; 
    var radioAry = radio_interfaces.match(RegExp(pattern,"g"));
    if (radioAry) {
      for (i=0; i<radioAry.length; i++) {
        rslt = radioAry[i].match(pattern);
        temp = rslt[3].match(/(\S+) (\S+)/);
        if (temp)
          rslt[3] = temp[1] + "<sup>" + temp[2] + "</sup>";
        displayName = rslt[2]+"-"+rslt[3].toUpperCase().replace(/Z/, "z");
        radioName = rslt[1];
        clickFunc = "setRadioLinkCookie('"+radioName+"')";
        menu__Child(P2,P1,curPg, "ap_network-if.shtml", "ap_network-if_802-11.shtml>"+radioName, displayName, "", clickFunc);
      }
    }
    if(isPegasus())
        menu__Child(P2,P1,curPg, "ap_network-if.shtml", "ap_network-if_pilr.shtml", "Power Injector LR", "", "");
  }
  if (menu_Parent(P2,P1,curPg, "ap_sec.shtml", "ap_sec.shtml", "SECURITY")) {
    if (!is520()) {
        menu__Child(P2,P1,curPg, "ap_sec.shtml", "ap_sec_local-admin-access.shtml", "Admin Access", "", "");
    }
    if (hasCapability("DOT11_CORE")) {
        menu__Child(P2,P1,curPg, "ap_sec.shtml", "ap_sec_ap-key-security.shtml", "Encryption Manager", "", "setVLANPage(0)");
        menu__Child(P2,P1,curPg, "ap_sec.shtml", "ap_sec_ap-client-security.shtml", "SSID Manager", "", "");
    }
        menu__Child(P2,P1,curPg, "ap_sec.shtml", "ap_sec_network-security_a.shtml", "Server Manager", "", "");
    if (hasCapability("DOT11_CORE") && hasCapability("DOT1X")) {
        menu__Child(P2,P1,curPg, "ap_sec.shtml", "ap_sec_dot1x-security.shtml", "AP Authentication", "", "");
    }
    if ((!is520()) && (hasCapability("MFP_DETECTOR") || hasCapability("MFP_DISTRIBUTOR")) && !is1430()) {
      menu__Child(P2,P1,curPg, "ap_sec.shtml", "ap_sec_ids_mfp.shtml", "Intrusion Detection", "", "");
    }
    if (!is520() && hasCapability("RAD_SVR")) {
      menu__Child(P2,P1,curPg, "ap_sec.shtml", "ap_sec_lrs.shtml", "Local RADIUS Server", "", "");
    }
    if (hasCapability("AP")) {
        menu__Child(P2,P1,curPg, "ap_sec.shtml", "ap_sec_ap-client-security-adv_a.shtml", "Advanced Security", "", "");
    } else {
        menu__Child(P2,P1,curPg, "ap_sec.shtml", "ap_sec_ap-client-security-adv_c.shtml", "Advanced Security", "", "");
    }
  }
  if (  menu_Parent(P2,P1,curPg, "ap_services.shtml", "ap_services.shtml", "SERVICES")) {
        menu__Child(P2,P1,curPg, "ap_services.shtml", "ap_services_console-telnet.shtml", "Telnet/SSH", "telnetSsh()", "", "");
    if (hasCapability("DOT11_CORE")) {
      if(!isAnyBridge()) {
        menu__Child(P2,P1,curPg, "ap_services.shtml", "ap_services_hot-standby.shtml", "Hot Standby", "hotStandby()", "", "");
      }
    }
        menu__Child(P2,P1,curPg, "ap_services.shtml", "ap_services_cdp.shtml", "CDP", "cdp()", "");
        menu__Child(P2,P1,curPg, "ap_services.shtml", "ap_services_dns.shtml", "DNS", "dns()", "");
    if (hasCapability("DOT11_CORE")) {
        menu__Child(P2,P1,curPg, "ap_services.shtml", "ap_services_filters.shtml", "Filters", "filter()", "");
    }
        menu__Child(P2,P1,curPg, "ap_services.shtml", "ap_services_http.shtml", "HTTP", "http()", "");
    if (hasCapability("DOT11_CORE")) {
        menu__Child(P2,P1,curPg, "ap_services.shtml", "ap_services_qos.shtml", "QoS", "qos()", "");
    }
    if (hasCapability("DOT11_CORE")) {
      if(isAnyAP()){
        menu__Child(P2,P1,curPg, "ap_services.shtml", "ap_services_voice-traffic.shtml", "STREAM", "stream()", "");
      }
    }
	if(!is520()) {
        menu__Child(P2,P1,curPg, "ap_services.shtml", "ap_services_snmp.shtml", "SNMP", "snmp()", "");
	}

        menu__Child(P2,P1,curPg, "ap_services.shtml", "ap_services_sntp.shtml", "SNTP", "sntp()", "");
    if (hasCapability("DOT11_CORE")) {
        menu__Child(P2,P1,curPg, "ap_services.shtml", "ap_services_vlan.shtml", "VLAN", "vlan()", "");
    }
    if (isAnyBridge()) {
        menu__Child(P2,P1,curPg, "ap_services.shtml", "ap_services_stp.shtml", "STP", "stp()", "");
    }
    if (hasCapability("ARP_CACHE")) {
        menu__Child(P2,P1,curPg, "ap_services.shtml", "ap_services_arp.shtml", "ARP Caching", "arp()", "");
    }
  }
  if (!is520() && !is1430() && (hasCapability("WLCCP_AP") || hasCapability("WLCCP_WDS"))) {
    if (menu_Parent(P2,P1,curPg, "ap_contextmgr.shtml", "ap_contextmgr.shtml", "WIRELESS SERVICES")) {
      if (hasCapability("WLCCP_AP")) {
        menu__Child(P2,P1,curPg, "ap_contextmgr.shtml", "ap_contextmgr_ap.shtml", "AP", "", "");
      }
      if (hasCapability("WLCCP_WDS")) {
        menu__Child(P2,P1,curPg, "ap_contextmgr.shtml", "ap_contextmgr_scm_summary.shtml", "WDS", "", "");
      }
    }
  }
  if (  menu_Parent(P2,P1,curPg, "ap_system-sw.shtml", "ap_system-sw.shtml", "SYSTEM SOFTWARE")) {
        if (!is520()) {
          menu__Child(P2,P1,curPg, "ap_system-sw.shtml", "ap_system-sw_upgrade.shtml", "Software Upgrade", "", "");
        }
        menu__Child(P2,P1,curPg, "ap_system-sw.shtml", "ap_system-sw_sysconfig.shtml", "System Configuration", "", "");
  }
  if (  menu_Parent(P2,P1,curPg, "ap_event-log.shtml", "ap_event-log.shtml", "EVENT LOG")) {
        menu__Child(P2,P1,curPg, "ap_event-log.shtml", "ap_event-log_config-options.shtml", "Configuration Options", "", "");
  }
  menu_Parent(P2, P1, curPg, "", "ap_sec_band_select.shtml", "BAND SELECT");
  menu_Parent(P2, P1, curPg, "", onclick="javascript:logoutNow()", "LOGOUT");
  menuClose();
}

function ifTitle()
{
  return(titleOfCurrentPage);
}

// input :
//   radioInt = ["Dot11Radio-Any" | "Dot11Radio#"]
//   role = ["AP-ROOT" | "CLIENT" | "CLIENT-WGB" | "BRIDGE-ROOT" | ... ]

function isRadioRole(radioInt, role) {

  var pattern;
  var results;

  radioInt = radioInt == "Dot11Radio-Any" ? "Dot11Radio\\d+" : radioInt;
  pattern = radioInt + ":[^\\r\\n;]+:(" + role + ");";
  results = radio_station_role.match(pattern);

  if (results)
      return true;
  else
     return false;
}

// input :
//   radioInt = ["Dot11Radio-Any" | "Dot11Radio#"]

function isRadioRoleAP(radioInt) {
  return isRadioRole(radioInt, "AP-ROOT|AP-ROOT-FALLBACK-SHUTDOWN|AP-ROOT-FALLBACK-REPEATER");
}

function isStationRoleNonRootBridge(radioInt) {
  return isRadioRole(radioInt, "CLIENT");
}

function isAnyAP() {
  var pattern;
  var results;

  pattern = "AP-ROOT|AP-ROOT-FALLBACK-SHUTDOWN|AP-ROOT-FALLBACK-REPEATER";
  results = radio_station_role.match(pattern);

  if (results)
      return true;

  return false;
}
function isAnyBridge() {
  var pattern;
  var results;

  pattern = "BRIDGE|INSTALL|:CLIENT;";
  results = radio_station_role.match(pattern);

  if (results)
      return true;

  return false;
}

function radioRole(radio, roleStr, role) {
  return isRadioRole("Dot11Radio" + radio, role);
}


// ture - if 1300 radio 0 station role is one of the following:
// station-role root ap-only [fallback <repeater|shutdown>]

function is1300RoleAP(roleCmdLine) {

    if (radioRole(0, roleCmdLine, "AP-ROOT")
        || radioRole(0, roleCmdLine, "AP-ROOT-FALLBACK-SHUTDOWN")
        || radioRole(0, roleCmdLine, "AP-ROOT-FALLBACK-REPEATER"))
    {
        return true;
    }
    return false;

}

// ture - if 1300 radio 0 station role is one of the following:
// station-role non-root

function is1300RoleNonRootBr(roleCmdLine) {

    return radioRole(0, roleCmdLine, "CLIENT");
}

// ture - if 1300 radio 0 station role is one of the following:
// station-role root

function is1300RoleRootBr(roleCmdLine) {

    return radioRole(0, roleCmdLine, "BRIDGE-ROOT");
}

// ture - if 1300 radio 0 station role is one of the following:
// station-role install <root|automatic>
// In case automatic is selected to root

function is1300RoleInstallRootBr(roleCmdLine) {
  if (radioRole(0, roleCmdLine, "BRIDGE-ROOT-MANUALINSTALL")
      || radioRole(0, roleCmdLine, "BRIDGE-ROOT-AUTOINSTALL")) 
   {
      return true;
   }
   return false;
}

// ture - if 1300 radio 0 station role is one of the following:
// station-role install <non-root|automatic>
// In case automatic is selected to non-root

function is1300RoleInstallNonRootBr(roleCmdLine) {
  if (radioRole(0, roleCmdLine, "CLIENT-AUTOINSTALL") 
      || radioRole(0, roleCmdLine, "CLIENT-MANUALINSTALL")) 
  {
     return true;
  }
  return false;
}

// ture - if 1300 radio 0 station role is one of the following:
// station-role install <root|non-root|automatic>

function is1300RoleInstall(roleCmdLine) {
  if (is1300RoleInstallRootBr(roleCmdLine) || is1300RoleInstallNonRootBr(roleCmdLine))
  {
      return true;
  }
  return false;
}

// true - if station role is one of the following:
// station-role workgroup-bridge

function isStationRoleWGB(radioInt) {

    return isRadioRole(radioInt, "CLIENT-WGB");

}

// ture - if 1300 radio 0 station role is one of the following:
// station-role root
// station-role non-root
// station-role install <root|non-root|automatic>

function is1300BridgeRole(roleCmdLine) {
    if (is1300RoleRootBr(roleCmdLine) || is1300RoleNonRootBr(roleCmdLine)
        || is1300RoleInstall(roleCmdLine)) 
    {
       return true;
    }
    return false;
}

// ture - if 1300 radio 0 station role is one of the following:
// station-role root
// station-role install root
// station-role root ap-only [fallback <repeater|shutdown>]

function is1300RoleRoot(roleCmdLine) {

  if (is1300RoleRootBr(roleCmdLine) || is1300RoleAP(roleCmdLine)
      || is1300RoleInstallRootBr(roleCmdLine))
  {
      return true;
  }
  return false;
}

function aesSupport(aesCap, ifnum){
  var pattern = "Dot11Radio" + ifnum + ": AES-CCM"
  if(aesCap.indexOf(pattern) != -1)
    return true;
  else
    return false;
}

function  roleClient(radio, roleCmdLine) {
  var pattern = "Dot11Radio(\\d+)";
  var rn = radio.match(pattern);
  if(rn){
    if( radioRole(rn[1], roleCmdLine, "CLIENT-WGB") || radioRole(rn[1], roleCmdLine, "CLIENT")){
      return true;
    }
  }
  
  return false;
}
/***********************************************/
function roleRadio(num, role) {

  var pattern;
  var results;

  pattern = "Dot11Radio"+num+":[^:]+:([^;]+);";
  results = radio_station_role.match(pattern);

  if (results){
     	results = results[1].match(role);
     	if(results)
     	  return true;
  }
  
  return false;
}

function  clientRole(num) { // non-root or WGB

  if( roleRadio(num, "CLIENT-WGB") || roleRadio(num, "CLIENT")){
      return true;
  }
  
  return false;
}

function repeaterRole(num) { // REPEATER or FALLBACK-REPEATER

  if( roleRadio(num, "REPEATER")){
      return true;
  }
  
  return false;
}

function wgbRole(num) { // Workgroup Bridge

  if( roleRadio(num, "CLIENT-WGB")){
      return true;
  }
  
  return false;
}

function antennaDiv(div, radio){
  var pattern = radio + ": TRUE"
  if(div.indexOf(pattern) != -1)
    return true;
  else
    return false;
}

function isEthernetUp(showIntBrief)
{
  var pattern = "Ethernet0\\s+\\S+\\s+\\S+\\s+\\S+\\s+(\\S+)\\s+(\\S+)"
  var retVal = false; 
  results = showIntBrief.match(pattern);
  if (results) {
    if ((results[1] == "up") && (results[2] == "up")) {
      retVal = true;
    } 
  }
  return retVal;
}

